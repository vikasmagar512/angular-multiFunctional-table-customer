export const environment = {
  production: true,
  // URL of production API
  apiUrl: 'http://localhost:3000'
};
