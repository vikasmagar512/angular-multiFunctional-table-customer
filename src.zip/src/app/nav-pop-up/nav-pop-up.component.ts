import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav-pop-up',
  templateUrl: './nav-pop-up.component.html',
  styleUrls: ['./nav-pop-up.component.css']
})
export class NavPopUpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
