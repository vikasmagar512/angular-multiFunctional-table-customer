
export interface Customer{
  "id":string;
  "name": string;
  "email": string;
  "address": string;
  "img":string;
  "contact":string;
}
