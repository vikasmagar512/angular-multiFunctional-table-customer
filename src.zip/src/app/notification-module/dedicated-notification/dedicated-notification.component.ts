import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dedicated-notification',
  templateUrl: './dedicated-notification.component.html',
  styleUrls: ['./dedicated-notification.component.css']
})
export class DedicatedNotificationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
