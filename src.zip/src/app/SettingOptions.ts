export interface SettingOptions{
      "name":string;
      "id": string;
      "selected": boolean;
    }